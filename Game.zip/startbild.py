from TextRenderer import TextRenderer
from Grids import Grid
#from Renderer import Renderer
import pygame
import time

r = TextRenderer(15, 20)
g = Grid(r.width, r.height, r)

play = [[4, 18, 1, 0], [5, 18, 1, 0], [6, 18, 1, 0], [7, 18, 1, 0], [8, 18, 1, 0], [9, 18, 1, 0], [10, 18, 1, 0],
        [11, 18, 1, 0], [4, 17, 1, 0], [4, 16, 1, 0], [4, 15, 1, 0], [4, 14, 1, 0], [4, 13, 1, 0], [4, 12, 1, 0],
        [4, 11, 1, 0], [4, 10, 1, 0], [4, 9, 1, 0], [4, 8, 1, 0], [4, 7, 1, 0], [4, 6, 1, 0], [4, 5, 1, 0],
        [4, 4, 1, 0],
        [4, 3, 1, 0], [4, 2, 1, 0], [4, 1, 1, 0], [5, 1, 1, 0], [6, 1, 1, 0], [7, 1, 1, 0], [8, 1, 1, 0], [9, 1, 1, 0],
        [10, 1, 1, 0], [11, 1, 1, 0], [11, 2, 1, 0], [11, 3, 1, 0], [11, 4, 1, 0], [11, 5, 1, 0], [11, 6, 1, 0],
        [11, 7, 1, 0], [11, 8, 1, 0], [11, 9, 1, 0], [11, 10, 1, 0], [11, 11, 1, 0], [11, 12, 1, 0], [11, 13, 1, 0],
        [11, 13, 1, 0], [11, 14, 1, 0], [11, 15, 1, 0], [11, 16, 1, 0], [11, 17, 1, 0], [11, 18, 1, 0], [3, 16, 0, 0],
        [2, 16, 0, 0], [2, 17, 0, 0], [1, 16, 0, 0], [1, 15, 0, 0], [3, 11, 0, 0], [2, 11, 0, 0], [2, 12, 0, 0],
        [1, 11, 0, 0], [1, 10, 0, 0], [6, 16, 0, 0], [6, 15, 0, 0], [6, 14, 0, 0], [7, 14, 0, 0], [8, 14, 0, 0],
        [8, 15, 0, 0], [8, 16, 0, 0], [7, 16, 0, 0], [9, 16, 0, 0], [6, 12, 0, 0], [7, 12, 0, 0], [8, 12, 0, 0],
        [9, 12, 0, 0], [9, 11, 0, 0], [6, 9, 0, 0], [7, 9, 0, 0], [8, 9, 0, 0], [9, 9, 0, 0], [6, 8, 0, 0],
        [6, 7, 0, 0],
        [7, 7, 0, 0], [8, 7, 0, 0], [9, 7, 0, 0], [8, 8, 0, 0], [6, 5, 0, 0], [7, 5, 0, 0], [8, 5, 0, 0], [9, 4, 0, 0],
        [8, 4, 0, 0], [6, 3, 0, 0], [7, 3, 0, 0], [8, 3, 0, 0], [3, 5, 0, 0], [2, 5, 0, 0], [2, 6, 0, 0], [1, 4, 0, 0],
        [1, 5, 0, 0]]

# for i in range(len(play)):
#    play[i][2] = 7

g.render(play)


def color_change():  # idee
    for i in range(0, len(play)):
        if play[i][2] == 1:
            play[i][2] = 2
    g.render(play)
    time.sleep(0.5)

    for i in range(0, len(play)):
        if play[i][2] == 2:
            play[i][2] = 1
    g.render(play)
    time.sleep(0.5)

pygame.init()

pygame.display.set_mode((100, 100))
pygame.joystick.init()

running = True
#x = Renderer()

while running:

    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            running = False
    event = pygame.event.poll()

    # Keyboard
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RETURN:
            running = False
            print("Enter")
            for i in range(len(play)):
                play[i][2] = 7
            g.render(play)
            #x.start()

    # NES
    if event.type == pygame.JOYBUTTONDOWN:
        if event.button == 1 or event.button == 0:  # A or B Button
            for i in range(len(play)):
                play[i][2] = 7
            g.render(play)
            #x.start()

    color_change()