from TextRenderer import TextRenderer
from Grids import Grid
import pygame
import time, random

r = TextRenderer(15, 20)
g = Grid(r.width, r.height, r)

play = [[11, 18, 1, 0], [10, 18, 1, 0], [9, 18, 1, 0], [8, 18, 1, 0], [7, 18, 1, 0], [6, 18, 1, 0], [5, 18, 1, 0],
        [4, 18, 1, 0], [4, 17, 1, 0], [4, 16, 1, 0], [4, 15, 1, 0], [4, 14, 1, 0], [4, 13, 1, 0], [4, 12, 1, 0],
        [4, 11, 1, 0], [4, 10, 1, 0], [4, 9, 1, 0], [4, 8, 1, 0], [4, 7, 1, 0], [4, 6, 1, 0], [4, 5, 1, 0],
        [4, 4, 1, 0],
        [4, 3, 1, 0], [4, 2, 1, 0], [4, 1, 1, 0], [5, 1, 1, 0], [6, 1, 1, 0], [7, 1, 1, 0], [8, 1, 1, 0], [9, 1, 1, 0],
        [10, 1, 1, 0], [11, 1, 1, 0], [11, 2, 1, 0], [11, 3, 1, 0], [11, 4, 1, 0], [11, 5, 1, 0], [11, 6, 1, 0],
        [11, 7, 1, 0], [11, 8, 1, 0], [11, 9, 1, 0], [11, 10, 1, 0], [11, 11, 1, 0], [11, 12, 1, 0], [11, 13, 1, 0],
        [11, 13, 1, 0], [11, 14, 1, 0], [11, 15, 1, 0], [11, 16, 1, 0], [11, 17, 1, 0], [3, 16, 0, 0],
        [2, 16, 0, 0], [2, 17, 0, 0], [1, 16, 0, 0], [1, 15, 0, 0], [3, 11, 0, 0], [2, 11, 0, 0], [2, 12, 0, 0],
        [1, 11, 0, 0], [1, 10, 0, 0], [6, 16, 0, 0], [6, 15, 0, 0], [6, 14, 0, 0], [7, 14, 0, 0], [8, 14, 0, 0],
        [8, 15, 0, 0], [8, 16, 0, 0], [7, 16, 0, 0], [9, 16, 0, 0], [6, 12, 0, 0], [7, 12, 0, 0], [8, 12, 0, 0],
        [9, 12, 0, 0], [9, 11, 0, 0], [6, 9, 0, 0], [7, 9, 0, 0], [8, 9, 0, 0], [9, 9, 0, 0], [6, 8, 0, 0],
        [6, 7, 0, 0],
        [7, 7, 0, 0], [8, 7, 0, 0], [9, 7, 0, 0], [8, 8, 0, 0], [6, 5, 0, 0], [7, 5, 0, 0], [8, 5, 0, 0], [9, 4, 0, 0],
        [8, 4, 0, 0], [6, 3, 0, 0], [7, 3, 0, 0], [8, 3, 0, 0], [3, 5, 0, 0], [2, 5, 0, 0], [2, 6, 0, 0], [1, 4, 0, 0],
        [1, 5, 0, 0]]

for i in range(0, len(play)):
    if play[i][0] == 1 or play[i][0] == 2 or play[i][0] == 3:
        play[i][2] = 5
for i in range(0, len(play)):
    if play[i][2] == 1:
        play[i][2] = 0

startbild = [[1, 17, 0, 0], [2, 17, 0, 0], [3, 17, 0, 0], [4, 17, 0, 0], [1, 16, 0, 0], [1, 15, 0, 0], [2, 15, 0, 0],
             [3, 15, 0, 0], [4, 16, 0, 0], [4, 15, 0, 0], [1, 13, 0, 0], [2, 13, 0, 0], [3, 13, 0, 0], [4, 13, 0, 0],
             [1, 11, 0, 0],
             [2, 11, 0, 0], [3, 11, 0, 0], [4, 11, 0, 0], [1, 10, 0, 0], [1, 9, 0, 0], [2, 9, 0, 0], [3, 9, 0, 0],
             [4, 9, 0, 0], [1, 7, 0, 0], [2, 7, 0, 0], [3, 7, 0, 0], [4, 7, 0, 0], [1, 6, 0, 0], [4, 6, 0, 0],
             [1, 5, 0, 0], [2, 5, 0, 0], [3, 5, 0, 0], [4, 5, 0, 0], [7, 17, 0, 0], [7, 16, 0, 0], [7, 15, 0, 0],
             [8, 15, 0, 0], [9, 15, 0, 0], [10, 15, 0, 0], [11, 17, 0, 0], [11, 16, 0, 0], [11, 15, 0, 0],
             [10, 17, 0, 0], [7, 13, 0, 0], [8, 13, 0, 0], [9, 13, 0, 0], [10, 13, 0, 0], [11, 13, 0, 0],
             [11, 12, 0, 0], [11, 11, 0, 0], [10, 11, 0, 0], [9, 11, 0, 0], [8, 11, 0, 0], [7, 11, 0, 0], [7, 9, 0, 0],
             [8, 9, 0, 0], [9, 9, 0, 0], [10, 9, 0, 0], [11, 9, 0, 0], [7, 8, 0, 0], [7, 7, 0, 0], [8, 7, 0, 0],
             [9, 7, 0, 0], [7, 6, 0, 0], [7, 5, 0, 0], [8, 5, 0, 0], [9, 5, 0, 0], [10, 5, 0, 0], [11, 5, 0, 0],
             [7, 3, 0, 0], [8, 3, 0, 0], [9, 3, 0, 0], [9, 3, 0, 0], [11, 3, 0, 0], [7, 2, 0, 0], [7, 1, 0, 0],
             [8, 1, 0, 0], [9, 1, 0, 0], [9, 2, 0, 0], [10, 3, 0, 0], [5, 2, 5, 0], [4, 2, 5, 0], [4, 3, 5, 0],
             [3, 2, 5, 0], [2, 2, 5, 0], [2, 1, 5, 0]]


def color_game():
    time.sleep(0.5)
    c = [1, 1, 6]
    for k in range(2):
        for i in range(0, len(startbild)):
            if (startbild[i][0] == 4 or startbild[i][0] == 11) and startbild[i][2] == 0:
                startbild[i][2] = random.choice(c)
                g.render(startbild)
                time.sleep(0.05)


def dino_jump():
    for i in range(2):
        for i in range(80, 86):
            startbild[i][0] -= 1
        g.render(startbild)
        time.sleep(0.3)
        for i in range(80, 86):
            startbild[i][0] += 1
        g.render(startbild)
        time.sleep(0.2)
    time.sleep(0.2)


def render_play():
    c = [1, 1, 6]
    for i in range(0, len(play)):
        if play[i][2] == 0 and (play[i][0] == 4 or play[i][0] == 11 or play[i][1] == 1 or play[i][1] == 18):
            play[i][2] = random.choice(c)
            g.render(play)
            time.sleep(0.03)


g.render(startbild)
color_game()
dino_jump()
render_play()
g.render(play)

pygame.init()
pygame.display.set_mode((100, 100))
pygame.joystick.init()

running = True

while running:
    running_game = False
    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            running = False

    event = pygame.event.poll()

    # Keyboard
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_RETURN:
            running = False
            print("Enter")
            for i in range(len(play)):
                play[i][2] = 7
            g.render(play)
            from Game import Game

            x = Game()

        if event.key == pygame.K_a:
            running = False
            print("Enter")
            for i in range(len(play)):
                play[i][2] = 7
            g.render(play)
            from Game_Ai import GameAi

            y = GameAi()
            y.start()

        if event.key == pygame.K_b:
            running = False

    # SNES
    if event.type == pygame.JOYBUTTONDOWN:
        if event.button == 1 or event.button == 0:  # A or B Button
            for i in range(len(play)):
                play[i][2] = 7
            from Game import Game

            x = Game()
            g.render(play)
            print("hey")
